# import the Flask class from the flask module
from flask import Flask, session, render_template, redirect, url_for, request,  Response
from flaskext.mysql import MySQL
from flask_session import Session
import MySQLdb
from flask_pymongo import PyMongo
import json
from py2neo import Graph, authenticate
from py2neo import Node, Relationship

import re
from collections import Counter


app = Flask(__name__)


@app.route("/")
def hello():
    return "Hello World!"

@app.route('/success/<query>')
def success(query):
	a=[]
	a.append(query)
	return render_template('index.html', name= a)

@app.route('/search',methods = ['POST', 'GET'])
def search():
	user="hello"
	if request.method=="POST":
		user = request.form['nm']
	return redirect(url_for('success',query = user))


@app.route('/home')
def home():
	return render_template('index.html')


if __name__ == '__main__':
#	app.secret_key = 'qwerty'
	app.run(host='0.0.0.0', debug=True)
